package com.otaghema.app
import android.app.*
import android.content.*
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class LoveMessagingService: FirebaseMessagingService(){
 override fun onMessageReceived(m:RemoteMessage){
  val ch="love_events"; val nm=getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
  if(android.os.Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(NotificationChannel(ch,"اتاق ما",NotificationManager.IMPORTANCE_HIGH))
  val n=NotificationCompat.Builder(this,ch).setSmallIcon(android.R.drawable.ic_dialog_info)
   .setContentTitle(m.notification?.title ?: "اتاق ما ❤️").setContentText(m.notification?.body ?: "یه پیام جدید داری")
   .setAutoCancel(true).build();nm.notify((System.currentTimeMillis()%100000).toInt(),n)
 }
 override fun onNewToken(token:String){getSharedPreferences("push",0).edit().putString("token",token).apply()}
}