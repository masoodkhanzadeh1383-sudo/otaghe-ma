package com.otaghema.app

import android.app.*
import android.os.Bundle
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class MainActivity: Activity() {
 private val db=FirebaseFirestore.getInstance()
 private val auth=FirebaseAuth.getInstance()
 private var roomId=""
 private lateinit var root:LinearLayout
 private fun t(s:String,z:Float=18f)=TextView(this).apply{text=s;textSize=z;setTextColor(Color.WHITE);gravity=Gravity.CENTER;padding(10)}
 private fun b(s:String,a:()->Unit)=Button(this).apply{text=s;setOnClickListener{a()};setTextColor(Color.WHITE);setBackgroundColor(Color.rgb(117,55,108))}
 override fun onCreate(x:Bundle?){super.onCreate(x); if(auth.currentUser==null) auth.signInAnonymously().addOnSuccessListener{home()} else home()}
 private fun base():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,28,24,18);setBackgroundColor(Color.rgb(20,12,25))}
 private fun home(){root=base();root.addView(t("❤️ اتاق ما",30f));root.addView(t("اتصال دو نفره، خصوصی و آنلاین"))
  val code=EditText(this).apply{hint="کد اتاق";setTextColor(Color.WHITE);setHintTextColor(Color.LTGRAY)}
  root.addView(code);root.addView(b("ورود به اتاق"){roomId=code.text.toString().trim();if(roomId.isNotEmpty())room()})
  root.addView(b("ساخت اتاق جدید"){roomId=java.util.UUID.randomUUID().toString().take(8);db.collection("rooms").document(roomId).set(mapOf("createdBy" to auth.uid));showCode()})
  setContentView(root)}
 private fun showCode(){root=base();root.addView(t("اتاق ساخته شد ❤️",25f));root.addView(t("کد اتصال:\n$roomId",30f));root.addView(t("این کد را فقط با شریک خود به اشتراک بگذارید"));root.addView(b("ورود به اتاق"){room()});setContentView(root)}
 private fun room(){root=base();root.addView(t("❤️ اتاق ما",28f))
  root.addView(b("💬 چت"){chat()});root.addView(b("🥹 دلم برات تنگ شده"){sendEvent("miss","🥹 دلم برات تنگ شده")})
  root.addView(b("🫂 بغل فرستادم"){sendEvent("hug","🫂 یه بغل برای تو")})
  root.addView(b("🌙 حال من"){mood()});root.addView(b("📝 یادداشت مشترک"){notes()})
  root.addView(t("کد اتاق: $roomId",13f));setContentView(root)}
 private fun sendEvent(type:String,text:String){db.collection("rooms").document(roomId).collection("events").add(mapOf("from" to auth.uid,"type" to type,"text" to text,"time" to System.currentTimeMillis()));Toast.makeText(this,"ارسال شد ❤️",Toast.LENGTH_SHORT).show()}
 private fun chat(){root=base();root.addView(t("💬 چت",25f));val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};root.addView(list)
  db.collection("rooms").document(roomId).collection("messages").orderBy("time",Query.Direction.ASCENDING).addSnapshotListener{snap,_->
   list.removeAllViews();snap?.documents?.forEach{d->list.addView(t("${if(d.getString("from")==auth.uid)"من" else "او"}: ${d.getString("text")}",16f))}
  }
  val e=EditText(this).apply{hint="پیامت...";setTextColor(Color.WHITE);setHintTextColor(Color.LTGRAY)};root.addView(e)
  root.addView(b("ارسال"){val s=e.text.toString().trim();if(s.isNotEmpty()){db.collection("rooms").document(roomId).collection("messages").add(mapOf("from" to auth.uid,"text" to s,"time" to System.currentTimeMillis()));e.setText("")}})
  root.addView(b("← برگشت"){room()});setContentView(root)}
 private fun mood(){root=base();root.addView(t("🌙 حال من",25f));listOf("😊 خوبم","🥹 دلتنگم","😔 ناراحتم","❤️ عاشقتم","😴 خسته‌ام").forEach{s->root.addView(b(s){db.collection("rooms").document(roomId).collection("moods").document(auth.uid!!).set(mapOf("mood" to s,"time" to System.currentTimeMillis()));Toast.makeText(this,"حال تو ثبت شد",Toast.LENGTH_SHORT).show()})};root.addView(b("← برگشت"){room()});setContentView(root)}
 private fun notes(){root=base();root.addView(t("📝 یادداشت مشترک",25f));val e=EditText(this).apply{hint="یادداشت مشترک...";minLines=6;setTextColor(Color.WHITE);setHintTextColor(Color.LTGRAY)}
  root.addView(e);root.addView(b("ذخیره"){db.collection("rooms").document(roomId).collection("notes").add(mapOf("from" to auth.uid,"text" to e.text.toString(),"time" to System.currentTimeMillis()));Toast.makeText(this,"ذخیره شد ❤️",Toast.LENGTH_SHORT).show()})
  root.addView(b("← برگشت"){room()});setContentView(root)}
}