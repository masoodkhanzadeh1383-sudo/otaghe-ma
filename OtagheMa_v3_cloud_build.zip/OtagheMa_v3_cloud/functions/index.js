const {onDocumentCreated}=require("firebase-functions/v2/firestore");
const {initializeApp}=require("firebase-admin/app");
const {getFirestore}=require("firebase-admin/firestore");
const {getMessaging}=require("firebase-admin/messaging");
initializeApp();
exports.notifyRoomEvent=onDocumentCreated("rooms/{roomId}/events/{eventId}",async e=>{
 const data=e.data.data(), room=e.params.roomId, db=getFirestore();
 const members=(await db.collection("rooms").doc(room).collection("members").get()).docs.map(x=>x.id).filter(x=>x!==data.from);
 const tokens=[];
 for(const uid of members){const d=await db.collection("users").doc(uid).get();if(d.exists&&d.data().fcmToken)tokens.push(d.data().fcmToken)}
 if(!tokens.length)return;
 return getMessaging().sendEachForMulticast({tokens,notification:{title:"اتاق ما ❤️",body:data.text||"یه پیام جدید داری"}})
});